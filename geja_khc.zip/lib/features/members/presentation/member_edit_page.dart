import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../midibs/data/midib.dart';
import '../../midibs/data/midib_api.dart';
import '../data/member.dart';
import '../data/members_api.dart';

class MemberEditPage extends StatefulWidget {
  final String id;
  const MemberEditPage({super.key, required this.id});

  @override
  State<MemberEditPage> createState() => _MemberEditPageState();
}

class _MemberEditPageState extends State<MemberEditPage> {
  final api = MembersApi();
  final midibApi = MidibApi();

  late Future<Member> _future;
  final _name = TextEditingController();
  final _code = TextEditingController();

  List<Midib> _midibs = [];
  String? _midibId;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _future = api.getMember(widget.id); // <— positional
    _loadMidibs();
  }

  Future<void> _loadMidibs() async {
    final mids = await midibApi.listMidibs();
    mids.sort((a, b) => a.name.compareTo(b.name));
    if (!mounted) return;
    setState(() => _midibs = mids);
  }

  Future<void> _save(Member current) async {
    if (_name.text.trim().isEmpty || _code.text.trim().isEmpty || (_midibId ?? '').isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ስም፣ ኮድ እና ምድብ አስፈላጊ ናቸው')));
      return;
    }
    setState(() => _saving = true);
    try {
      await api.setMember(
        Member(
          id: current.id,
          name: _name.text.trim(),
          memberCode: _code.text.trim(),
          midibId: _midibId!,
        ),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('አባል ተስተካክሏል')));
      context.pop(true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ማስቀመጥ አልተሳካም: $e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Member>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snap.hasError) {
          return Scaffold(appBar: AppBar(leading: const BackButton()), body: Center(child: Text('Error: ${snap.error}')));
        }
        final m = snap.data!;
        _name.text = _name.text.isEmpty ? m.name : _name.text;
        _code.text = _code.text.isEmpty ? (m.memberCode ?? '') : _code.text;
        _midibId ??= m.midibId;

        return Scaffold(
          appBar: AppBar(leading: const BackButton(), title: const Text('አባል አርትዕ')),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextField(controller: _name, decoration: const InputDecoration(labelText: 'ስም', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: _code, decoration: const InputDecoration(labelText: 'የአባል ኮድ', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              InputDecorator(
                decoration: const InputDecoration(labelText: 'ምድብ', border: OutlineInputBorder()),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    value: _midibId,
                    items: _midibs.map((x) => DropdownMenuItem(value: x.id, child: Text(x.name))).toList(),
                    onChanged: (v) => setState(() => _midibId = v),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: _saving ? null : () => _save(m),
                icon: _saving
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.save),
                label: const Text('አባል አስቀምጥ'),
              ),
            ],
          ),
        );
      },
    );
  }
}
