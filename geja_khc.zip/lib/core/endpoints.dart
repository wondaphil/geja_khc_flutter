// Exact WebAPI routes
class ApiPaths {
	// Midib
	static const listMidibs  = '/api/GejaKhcAPI/GetMidibList';
	static const getMidib    = '/api/GejaKhcAPI/GetMidib';
	static const setMidib    = '/api/GejaKhcAPI/SetMidib';
	static const deleteMidib = '/api/GejaKhcAPI/DeleteMidib';

	// Member
	static const listMembersByMidib = '/api/GejaKhcAPI/GetMemberList';
	static const getAllMembers      = '/api/GejaKhcAPI/GetAllMembers';
	static const getMember          = '/api/GejaKhcAPI/GetMember';
	static const setMember          = '/api/GejaKhcAPI/SetMember';
	static const deleteMember       = '/api/GejaKhcAPI/DeleteMember';

	// Gender
	static const getGender          = '/api/GejaKhcAPI/GetGender';

	// Reports
	static const getEducationLevelByMidib = '/api/GejaKhcAPI/GetEducationLevelByMidib';
	static const getMaritalStatusByMidib  = '/api/GejaKhcAPI/GetMaritalStatusByMidib';
	static const getMembershipMeansByMidib= '/api/GejaKhcAPI/GetMembershipMeansByMidib';
	static const getSubcityByMidib        = '/api/GejaKhcAPI/GetSubcityByMidib';
	static const getGenderByMidib         = '/api/GejaKhcAPI/GetGenderByMidib';
}