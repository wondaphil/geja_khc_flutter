import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'home_page.dart';
import 'splash.dart';
import '../features/about/about_page.dart';
import '../features/midibs/presentation/midib_list_page.dart';
import '../features/midibs/presentation/midib_detail_page.dart';
import '../features/midibs/presentation/midib_new_page.dart';
import '../features/midibs/presentation/midib_edit_page.dart';
import '../features/members/presentation/member_list_page.dart';
import '../features/members/presentation/member_detail_page.dart';
import '../features/members/presentation/member_new_page.dart';
import '../features/members/presentation/member_edit_page.dart';
import '../features/reports/presentation/report_by_midib_page.dart';
import '../features/charts/presentation/charts_page.dart';
import '../features/settings/presentation/settings_page.dart';
import '../features/settings/presentation/server_address_page.dart';

const kBrandCyan = Color(0xFF00ADEF);

class GejaApp extends StatelessWidget {
  const GejaApp({super.key});
  static const double fontScaleFactor = 1.25;

	// Helper function to create scaled text theme
	TextTheme _getScaledTextTheme() {
	  final baseTheme = Typography.blackMountainView;
	  return TextTheme(
		displayLarge: baseTheme.displayLarge?.copyWith(fontSize: (baseTheme.displayLarge?.fontSize ?? 96) * fontScaleFactor),
		displayMedium: baseTheme.displayMedium?.copyWith(fontSize: (baseTheme.displayMedium?.fontSize ?? 60) * fontScaleFactor),
		displaySmall: baseTheme.displaySmall?.copyWith(fontSize: (baseTheme.displaySmall?.fontSize ?? 48) * fontScaleFactor),
		headlineLarge: baseTheme.headlineLarge?.copyWith(fontSize: (baseTheme.headlineLarge?.fontSize ?? 40) * fontScaleFactor),
		headlineMedium: baseTheme.headlineMedium?.copyWith(fontSize: (baseTheme.headlineMedium?.fontSize ?? 34) * fontScaleFactor),
		headlineSmall: baseTheme.headlineSmall?.copyWith(fontSize: (baseTheme.headlineSmall?.fontSize ?? 24) * fontScaleFactor),
		titleLarge: baseTheme.titleLarge?.copyWith(fontSize: (baseTheme.titleLarge?.fontSize ?? 20) * fontScaleFactor),
		titleMedium: baseTheme.titleMedium?.copyWith(fontSize: (baseTheme.titleMedium?.fontSize ?? 16) * fontScaleFactor),
		titleSmall: baseTheme.titleSmall?.copyWith(fontSize: (baseTheme.titleSmall?.fontSize ?? 14) * fontScaleFactor),
		bodyLarge: baseTheme.bodyLarge?.copyWith(fontSize: (baseTheme.bodyLarge?.fontSize ?? 16) * fontScaleFactor),
		bodyMedium: baseTheme.bodyMedium?.copyWith(fontSize: (baseTheme.bodyMedium?.fontSize ?? 14) * fontScaleFactor),
		bodySmall: baseTheme.bodySmall?.copyWith(fontSize: (baseTheme.bodySmall?.fontSize ?? 12) * fontScaleFactor),
		labelLarge: baseTheme.labelLarge?.copyWith(fontSize: (baseTheme.labelLarge?.fontSize ?? 14) * fontScaleFactor),
		labelMedium: baseTheme.labelMedium?.copyWith(fontSize: (baseTheme.labelMedium?.fontSize ?? 12) * fontScaleFactor),
		labelSmall: baseTheme.labelSmall?.copyWith(fontSize: (baseTheme.labelSmall?.fontSize ?? 11) * fontScaleFactor),
	  ).apply(fontFamily: 'Ethiopic', fontFamilyFallback: const ['Nyala', 'Noto Sans Ethiopic', 'sans-serif']);
	}
	
  @override
  Widget build(BuildContext context) {
     final theme = ThemeData(
		  useMaterial3: true,
		  colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF00ADEF)),
		  //fontFamily: 'Ethiopic',
		  //fontFamilyFallback: const ['Nyala', 'Noto Sans Ethiopic', 'sans-serif'],
		  textTheme: _getScaledTextTheme(),
		  scaffoldBackgroundColor: const Color(0xFFF3FBFE), // soft cyan-ish background
		  appBarTheme: const AppBarTheme(
			centerTitle: false,
		  ),
		  cardTheme: const CardThemeData( // <-- was CardTheme(...)
			elevation: 1,
			margin: EdgeInsets.all(12),
			shape: RoundedRectangleBorder(
			  borderRadius: BorderRadius.all(Radius.circular(16)),
			),
		  ),
		  inputDecorationTheme: const InputDecorationTheme(
			border: OutlineInputBorder(),
		  ),
		  elevatedButtonTheme: ElevatedButtonThemeData(
			style: ElevatedButton.styleFrom(
			  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
			  textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
			  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
			),
		  ),
		);

    final router = GoRouter(
      initialLocation: '/splash',
      routes: [
        GoRoute(path: '/splash', builder: (c, s) => const SplashPage()),
        GoRoute(path: '/', builder: (c, s) => const HomePage()),
        GoRoute(path: '/midibs', builder: (c, s) => const MidibListPage()),
        GoRoute(path: '/midibs/new', builder: (c, s) => const MidibNewPage()),
		GoRoute(path: '/about', builder: (c, s) => const AboutPage()),
        GoRoute(
		  path: '/midibs/:id',
		  builder: (context, s) => MidibDetailPage(
			id: s.pathParameters['id']!,
			name: s.uri.queryParameters['name'] ?? '',
			code: s.uri.queryParameters['code'] ?? '',
			pastor: s.uri.queryParameters['pastor'],
			remark: s.uri.queryParameters['remark'],
		  ),
		),
		GoRoute(
		  path: '/midibs/:id/edit',
		  builder: (context, s) => MidibEditPage(
			id: s.pathParameters['id']!,
			initialName: s.uri.queryParameters['name'] ?? '',
			initialCode: s.uri.queryParameters['code'] ?? '',
			initialPastor: s.uri.queryParameters['pastor'],
			initialRemark: s.uri.queryParameters['remark'],
		  ),
		),
        GoRoute(path: '/members', builder: (c, s) => const MemberListPage()),
        GoRoute(path: '/members/new', builder: (c, s) => const MemberNewPage()),
        GoRoute(
		  path: '/members/:id',
		  builder: (c, s) {
			final id = s.pathParameters['id']!;
			return MemberDetailPage(id: id);
		  },
		),
		GoRoute(path: '/members/:id/edit', builder: (c, s) => MemberEditPage(id: s.pathParameters['id'] ?? '')),
		GoRoute(
		  path: '/reports/by-midib',
		  builder: (c, s) => const ReportsByMidibPage(),
		),
		GoRoute(
		  path: '/charts',
		  builder: (context, state) => const ChartsPage(),
		),
		GoRoute(
		  path: '/settings',
		  builder: (c, s) => const SettingsPage(),
		),
		GoRoute(
		  path: '/settings/server',
		  builder: (c, s) => const ServerAddressPage(),
		),
      ],
    );

    return MaterialApp.router(
      title: 'Geja KHC',
      debugShowCheckedModeBanner: false,
      theme: theme,
      routerConfig: router,
    );
  }
}
