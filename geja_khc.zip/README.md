
# geja_khc scaffold (real API routes wired)

This package updates **endpoints and API calls** to match your CSV:
- Midib: GetMidibList, GetMidib, SetMidib, DeleteMidib
- Member: GetMemberList, GetAllMembers, GetMember, SetMember, DeleteMember

## Install deps (if not already):
```
flutter pub add go_router dio
```

## Android manifest (if not already):
- `<uses-permission android:name="android.permission.INTERNET" />`
- In `<application ...>`:
  - `android:usesCleartextTraffic="true"`
  - `android:networkSecurityConfig="@xml/network_security_config"`

## Run
```
flutter run --dart-define=API_BASE_URL=http://wondaphil-002-site5.qtempurl.com
```
