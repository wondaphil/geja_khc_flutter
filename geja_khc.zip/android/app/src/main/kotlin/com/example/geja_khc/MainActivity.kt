package com.example.geja_khc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
