geja_khc — Flutter scaffold (Midib feature)

Dependencies:
  flutter pub add dio go_router

Run:
  flutter run --dart-define=API_BASE_URL=http://wondaphil-002-site5.qtempurl.com
